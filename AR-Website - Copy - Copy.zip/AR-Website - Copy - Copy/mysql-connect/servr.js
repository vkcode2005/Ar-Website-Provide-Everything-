var express = require('express');
var app = express();
var connection = require('./database');

connection.connect(function(err) {
  if (err) throw err;
  console.log('✅ Connected to the database!');

  app.listen(3000, function() {
    console.log('🚀 App is listening on port 3000');
  });
});

app.get('/', function(req, res) {
  let sql = 'SELECT * FROM CONTENTS';
  connection.query(sql, function(err, results) {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});
