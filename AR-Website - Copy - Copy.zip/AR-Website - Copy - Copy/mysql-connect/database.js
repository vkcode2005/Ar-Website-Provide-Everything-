var mysql = require('mysql2');

var connection = mysql.createConnection({
  host: 'localhost',
  database: 'AR',
  user: 'root',
  password: 'Roronoazoro@2005'
});

module.exports = connection;